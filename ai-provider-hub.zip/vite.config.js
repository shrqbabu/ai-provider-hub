var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { handleData } from "./api/_lib/data-core";
import { handleKeys } from "./api/_lib/keys-core";
import { handleGateway } from "./api/_lib/gateway-core";
import { toCoreRequest, sendCoreResponse } from "./api/_lib/node-adapter";
// Dev-mode proxy that mirrors the production Vercel Edge Function
// (api/proxy/[...path].ts). Same URL scheme in both:
//   /api/proxy/openai/v1/chat/completions
//   /api/proxy/nvidia/v1/chat/completions
//   /api/proxy/custom/v1/chat/completions?target=https://x.example.com/v1
// The client sends the API key in `x-provider-key`; both dev and prod
// proxies rewrite it into `Authorization: Bearer <key>`.
var TARGETS = {
    openai: "https://api.openai.com",
    nvidia: "https://integrate.api.nvidia.com",
    anthropic: "https://api.anthropic.com",
    openrouter: "https://openrouter.ai",
};
var HOP_BY_HOP = new Set([
    "connection",
    "keep-alive",
    "transfer-encoding",
    "te",
    "trailer",
    "upgrade",
    "proxy-authorization",
    "proxy-authenticate",
]);
export default defineConfig(function (_a) {
    var mode = _a.mode;
    // Load non-VITE env (e.g. FIREBASE_SERVICE_ACCOUNT) into process.env so the
    // backend _lib code — shared with the Vercel functions — works in dev too.
    var env = loadEnv(mode, process.cwd(), "");
    for (var _i = 0, _b = Object.entries(env); _i < _b.length; _i++) {
        var _c = _b[_i], k = _c[0], v = _c[1];
        if (process.env[k] === undefined)
            process.env[k] = v;
    }
    return {
        plugins: [
            react(),
            // Dev backend — mirrors the Vercel Node functions (api/data.ts, api/keys.ts,
            // api/v1.ts) by calling the exact same _lib core handlers. Registered before
            // the proxy so /api/v1 (gateway) and /api/proxy (CORS) both work in dev.
            {
                name: "ai-provider-hub-dev-backend",
                configureServer: function (server) {
                    var _this = this;
                    var mount = function (prefix, handler, opts) {
                        server.middlewares.use(prefix, function (req, res) { return __awaiter(_this, void 0, void 0, function () {
                            var rawUrl, _a, pathPart, _b, qs, query, subPath, core, result, err_1;
                            var _c;
                            return __generator(this, function (_d) {
                                switch (_d.label) {
                                    case 0:
                                        _d.trys.push([0, 3, , 4]);
                                        rawUrl = (_c = req.url) !== null && _c !== void 0 ? _c : "/";
                                        _a = rawUrl.split("?"), pathPart = _a[0], _b = _a[1], qs = _b === void 0 ? "" : _b;
                                        query = new URLSearchParams(qs);
                                        subPath = (opts === null || opts === void 0 ? void 0 : opts.subPathFromUrl)
                                            ? pathPart.replace(/^\//, "")
                                            : "";
                                        core = toCoreRequest(req, subPath, query);
                                        return [4 /*yield*/, handler(core, Date.now())];
                                    case 1:
                                        result = _d.sent();
                                        return [4 /*yield*/, sendCoreResponse(res, result)];
                                    case 2:
                                        _d.sent();
                                        return [3 /*break*/, 4];
                                    case 3:
                                        err_1 = _d.sent();
                                        // eslint-disable-next-line no-console
                                        console.error("[dev-backend ".concat(prefix, "]"), err_1);
                                        res.statusCode = 500;
                                        res.setHeader("Content-Type", "application/json");
                                        res.end(JSON.stringify({
                                            error: err_1 instanceof Error ? err_1.message : "Server error",
                                        }));
                                        return [3 /*break*/, 4];
                                    case 4: return [2 /*return*/];
                                }
                            });
                        }); });
                    };
                    mount("/api/data", handleData);
                    mount("/api/keys", handleKeys);
                    mount("/api/v1", handleGateway, { subPathFromUrl: true });
                },
            },
            {
                name: "ai-provider-hub-dev-proxy",
                configureServer: function (server) {
                    var _this = this;
                    server.middlewares.use("/api/proxy", function (req, res) { return __awaiter(_this, void 0, void 0, function () {
                        var rawUrl, _a, pathPart, _b, qs, _c, providerKey, rest, upstreamPath, upstreamBase, params, target, parsed, q, targetURL, outHeaders, _i, _d, _e, key, value, k, providerToken, providerCookie, method, hasBody, body, _f, upstream, reader_1, pump_1, err_2;
                        var _this = this;
                        var _g, _h;
                        return __generator(this, function (_j) {
                            switch (_j.label) {
                                case 0:
                                    _j.trys.push([0, 6, , 7]);
                                    rawUrl = (_g = req.url) !== null && _g !== void 0 ? _g : "/";
                                    _a = rawUrl.split("?"), pathPart = _a[0], _b = _a[1], qs = _b === void 0 ? "" : _b;
                                    _c = pathPart
                                        .replace(/^\//, "")
                                        .split("/"), providerKey = _c[0], rest = _c.slice(1);
                                    upstreamPath = "/" + rest.join("/");
                                    upstreamBase = TARGETS[providerKey];
                                    params = new URLSearchParams(qs);
                                    if (providerKey === "custom") {
                                        target = params.get("target");
                                        if (!target) {
                                            send(res, 400, {
                                                error: "Missing ?target=<base-url>",
                                            });
                                            return [2 /*return*/];
                                        }
                                        try {
                                            parsed = new URL(target);
                                            upstreamBase = "".concat(parsed.protocol, "//").concat(parsed.host).concat(parsed.pathname.replace(/\/$/, ""));
                                        }
                                        catch (_k) {
                                            send(res, 400, { error: "Invalid ?target URL" });
                                            return [2 /*return*/];
                                        }
                                    }
                                    if (!upstreamBase) {
                                        send(res, 400, {
                                            error: "Unknown provider \"".concat(providerKey, "\""),
                                        });
                                        return [2 /*return*/];
                                    }
                                    params.delete("target");
                                    q = params.toString();
                                    targetURL = upstreamBase + upstreamPath + (q ? "?" + q : "");
                                    outHeaders = {};
                                    for (_i = 0, _d = Object.entries(req.headers); _i < _d.length; _i++) {
                                        _e = _d[_i], key = _e[0], value = _e[1];
                                        if (!value)
                                            continue;
                                        k = key.toLowerCase();
                                        if (HOP_BY_HOP.has(k))
                                            continue;
                                        if (k === "host" || k === "origin" || k === "referer")
                                            continue;
                                        if (k === "x-provider-key")
                                            continue;
                                        if (k === "x-provider-cookie")
                                            continue;
                                        outHeaders[key] = Array.isArray(value) ? value.join(",") : value;
                                    }
                                    providerToken = req.headers["x-provider-key"];
                                    if (providerToken) {
                                        outHeaders["Authorization"] = "Bearer ".concat(Array.isArray(providerToken) ? providerToken[0] : providerToken);
                                    }
                                    providerCookie = req.headers["x-provider-cookie"];
                                    if (providerCookie) {
                                        outHeaders["Cookie"] = Array.isArray(providerCookie)
                                            ? providerCookie[0]
                                            : providerCookie;
                                    }
                                    method = ((_h = req.method) !== null && _h !== void 0 ? _h : "GET").toUpperCase();
                                    hasBody = method !== "GET" && method !== "HEAD";
                                    if (!hasBody) return [3 /*break*/, 2];
                                    return [4 /*yield*/, readBody(req)];
                                case 1:
                                    _f = _j.sent();
                                    return [3 /*break*/, 3];
                                case 2:
                                    _f = undefined;
                                    _j.label = 3;
                                case 3:
                                    body = _f;
                                    return [4 /*yield*/, fetch(targetURL, {
                                            method: method,
                                            headers: outHeaders,
                                            body: body,
                                            redirect: "follow",
                                        })];
                                case 4:
                                    upstream = _j.sent();
                                    // eslint-disable-next-line no-console
                                    console.log("[proxy] ".concat(method, " ").concat(providerKey).concat(upstreamPath, " \u2192 ").concat(upstream.status));
                                    res.statusCode = upstream.status;
                                    upstream.headers.forEach(function (v, k) {
                                        var lk = k.toLowerCase();
                                        if (HOP_BY_HOP.has(lk))
                                            return;
                                        if (lk === "content-encoding" || lk === "content-length")
                                            return;
                                        res.setHeader(k, v);
                                    });
                                    if (!upstream.body) {
                                        res.end();
                                        return [2 /*return*/];
                                    }
                                    reader_1 = upstream.body.getReader();
                                    pump_1 = function () { return __awaiter(_this, void 0, void 0, function () {
                                        var _a, value, done;
                                        return __generator(this, function (_b) {
                                            switch (_b.label) {
                                                case 0: return [4 /*yield*/, reader_1.read()];
                                                case 1:
                                                    _a = _b.sent(), value = _a.value, done = _a.done;
                                                    if (done) {
                                                        res.end();
                                                        return [2 /*return*/];
                                                    }
                                                    res.write(Buffer.from(value));
                                                    return [2 /*return*/, pump_1()];
                                            }
                                        });
                                    }); };
                                    return [4 /*yield*/, pump_1()];
                                case 5:
                                    _j.sent();
                                    return [3 /*break*/, 7];
                                case 6:
                                    err_2 = _j.sent();
                                    // eslint-disable-next-line no-console
                                    console.error("[proxy error]", err_2);
                                    send(res, 502, {
                                        error: err_2 instanceof Error ? err_2.message : "Proxy failed",
                                    });
                                    return [3 /*break*/, 7];
                                case 7: return [2 /*return*/];
                            }
                        });
                    }); });
                },
            },
        ],
        resolve: {
            alias: {
                "@": path.resolve(__dirname, "./src"),
            },
        },
    };
});
function send(res, status, body) {
    res.statusCode = status;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(body));
}
function readBody(req) {
    return new Promise(function (resolve, reject) {
        var chunks = [];
        req.on("data", function (c) { return chunks.push(c); });
        req.on("end", function () { return resolve(new Uint8Array(Buffer.concat(chunks))); });
        req.on("error", reject);
    });
}
